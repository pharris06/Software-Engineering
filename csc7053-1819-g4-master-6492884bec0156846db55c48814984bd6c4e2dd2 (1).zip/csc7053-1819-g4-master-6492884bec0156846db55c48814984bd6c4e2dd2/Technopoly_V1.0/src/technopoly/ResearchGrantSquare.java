package technopoly;

import java.util.Scanner;

/**
 * Class for instantiating ResearchGrantSquare objects to be stored within the board array
 * The role of this square essentially emulates the GO square in monopoly
 * Methods stored in this class provide functionality to ResearchGrantSquare objects 
 * 
 *
 */
public class ResearchGrantSquare extends Square {

	public static final int GRANT_AMOUNT = 500;

	/**
	 * Default constructor
	 */
	public ResearchGrantSquare() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * constructor with arguments
	 * 
	 * @param squareName
	 */
	public ResearchGrantSquare(String squareName) {
		super(squareName);
		// TODO Auto-generated constructor stub
	}

	/**
	 * Adds resources to the player upon landing
	 */
	@Override
	public void landingEvent(Player[] player, Square[] board, Scanner scanner, int playerTurn) {
		System.out.println("\n" + player[playerTurn].getPlayerName() + " is entitled to a research grant and gains "
				+ GRANT_AMOUNT + " resources!");
		player[playerTurn].addResources(GRANT_AMOUNT);
		System.out.println(
				player[playerTurn].getPlayerName() + " now has " + player[playerTurn].getResources() + " resources!");
	}

	@Override
	public void displayDetails() {
		System.out.print("*** " + this.getSquareName() + " ***");
	}

}
