/**
 * 
 */
package technopoly;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Class for instantiating ResearchSquare objects to be stored within the board array
 * The role of this square essentially emulates the property squares in monopoly
 * Methods stored in this class provide functionality to ResearchSquare objects 
 * 
 * @author david
 *
 */
public class ResearchSquare extends Square {

	public static String[] researchSquareNames = { "Physically Based Rendering", "Virtual Reality",
			"Business Intelligence", "Analytics", "Machine Learning", "Payment Processing", "Market Analysis",
			"Viruses", "Phishing", "Spyware" };

	public static final String FIELD_GRAPHICS = "Graphics";
	public static final String FIELD_DATA = "Big Data";
	public static final String FIELD_FINTECH = "Fintech";
	public static final String FIELD_CYBER = "Cyber Security";

	public static final int GRAPHICS_BASE_PRICE = 600;
	public static final int DATA_BASE_PRICE = 1400;
	public static final int FINTECH_BASE_PRICE = 4000;
	public static final int CYBER_BASE_PRICE = 2600;

	public static final int DEFAULT_DEVELOPMENT_LEVEL = 0;
	public static final double DEVELOPMENT_COST_MULTIPLIER = 0.25;

	public static final double UNDEVELOPED_INVESTMENT_MULTIPLIER = 0.1;
	public static final double DEVELOPMENT_LEVEL1_INVESTMENT_MULTIPLIER = 0.25;
	public static final double DEVELOPMENT_LEVEL2_INVESTMENT_MULTIPLIER = 0.5;
	public static final double DEVELOPMENT_LEVEL3_INVESTMENT_MULTIPLIER = 0.75;
	public static final double DEVELOPMENT_LEVEL4_INVESTMENT_MULTIPLIER = 1.0;

	public static final double DEFAULT_INVESTMENT_MULTIPLIER = UNDEVELOPED_INVESTMENT_MULTIPLIER;

	/**
	 * Equivalent of colour in monopoly terminology
	 */
	private String fieldOfResearchName;

	/**
	 * Equivalent of houses / hotels in monopoly (Level 4 = Hotel)
	 */
	private int levelOfResearchDevelopment;
	private int squarePrice;
	private double investmentMultiplier;

	/**
	 * Set as player.getName when purchased
	 */
	private String squareOwner = " ";

	/**
	 * default constuctor
	 */
	public ResearchSquare() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Constructor with args
	 * 
	 * @param squareName
	 * @param fieldOfResearchName
	 * @param levelOfResearchDevelopment
	 * @param squarePrice
	 * @param investmentMultiplier
	 */
	public ResearchSquare(String squareName, String fieldOfResearchName, int levelOfResearchDevelopment,
			int squarePrice, double investmentMultiplier) {
		super(squareName);
		this.fieldOfResearchName = fieldOfResearchName;
		this.levelOfResearchDevelopment = levelOfResearchDevelopment;
		this.squarePrice = squarePrice;
		this.investmentMultiplier = investmentMultiplier;

	}

	/**
	 * @return the fieldOfResearchName
	 */
	public String getFieldOfResearchName() {
		return fieldOfResearchName;
	}

	/**
	 * @param fieldOfResearchName the fieldOfResearchName to set
	 */
	public void setFieldOfResearchName(String fieldOfResearchName) {
		this.fieldOfResearchName = fieldOfResearchName;
	}

	/**
	 * @return the levelOfResearchDevelopment
	 */
	public int getLevelOfResearchDevelopment() {
		return levelOfResearchDevelopment;
	}

	/**
	 * @param levelOfResearchDevelopment the levelOfResearchDevelopment to set
	 */
	public void setLevelOfResearchDevelopment(int levelOfResearchDevelopment) {
		this.levelOfResearchDevelopment = levelOfResearchDevelopment;
	}

	/**
	 * @return the squarePrice
	 */
	public int getSquarePrice() {
		return squarePrice;
	}

	/**
	 * @param squarePrice the squarePrice to set
	 */
	public void setSquarePrice(int squarePrice) {
		this.squarePrice = squarePrice;
	}

	/**
	 * @return the squareOwner
	 */
	public String getSquareOwner() {
		return squareOwner;
	}

	/**
	 * @param squareOwner the squareOwner to set
	 */
	public void setSquareOwner(String squareOwner) {
		this.squareOwner = squareOwner;
	}

	/**
	 * Method is called upon player landing, action is dependant on ownership of the
	 * landed square 
	 * 		- Not owned - Calls purchaseSquare method 
	 * 		- Owned by another player - Calls payRent method
	 * 		- Owned by the player landing - Prints statement indicating player has returned to their square
	 */
	@Override
	public void landingEvent(Player[] player, Square[] board, Scanner scanner, int playerTurn) {

		System.out.println("\n" + player[playerTurn].getPlayerName() + " has landed on a Research Square!");

		if (this.squareOwner.equals(player[playerTurn].getPlayerName())) {
			System.out.println("Welcome back " + player[playerTurn].getPlayerName() + "!\n");
		} else if (squareOwner.equals(" ")) {
			displayDetails();
			boolean flag = false;

			try {
				while (flag == false) {
					System.out.println("\nWould you like to purchase this property?");
					System.out.println("1. Yes");
					System.out.println("2. No");

					int userDecision = scanner.nextInt();
					scanner.nextLine(); // clear buffer

					switch (userDecision) {
					case 1:
						purchaseSquare(player[playerTurn]);
						flag = true;
						break;
					case 2:
						flag = true;
						break;
					default:
						System.out.println("Please input a valid value");
					}
				}
			} catch (InputMismatchException e) {
				System.err.println("Something went wrong...");
				scanner.nextLine(); // prepares scanner for next input to avoid infinite loop, recursive call not
									// necessary
			}
		} else {
			for (int loop = 0; loop < player.length; loop++) {
				if (this.squareOwner.equals(player[loop].getPlayerName())) {
					payRent(player[playerTurn], player[loop], board[player[playerTurn].getPlayerPosition()]);
				}
			}
		}
	}

	/**
	 * Assigns player's name to the squareOwner variable of the ResearchSquare.
	 * Subtracting resources depending on the price of the ResearchSquare.
	 * 
	 * @param player
	 */
	public void purchaseSquare(Player player) {

		this.squareOwner = player.getPlayerName();
		player.subtractResources(this.getSquarePrice());
		System.out.println(player.getPlayerName() + " has purchased " + super.getSquareName() + "!");
		System.out.println(player.getPlayerName() + " your resources are now: " + player.getResources());
	}

	/**
	 * 
	 * Method checks whether the player landing can afford the rent for landing on the 
	 * squareOwner's ResearchSquare, if not this sets the player's resources to 0.
	 * Otherwise, subtracts resources from the playerPlaying and adds the same value
	 * to the squareOwner. This is based on the value and development of the square.
	 * 
	 * @param playerPlaying
	 * @param squareOwner
	 * @param board
	 */
	public void payRent(Player playerPlaying, Player squareOwner, Square board) {

		int rent = rentCalculator(board);

		System.out.println(squareOwner.getPlayerName() + " is researching " + getSquareName());
		System.out.println("This has cost " + playerPlaying.getPlayerName() + " " + rent + " resources.");

		if (playerPlaying.getResources() - rent <= 0) {

			playerPlaying.setResources(0);

			System.out.println(playerPlaying.getPlayerName() + " you have no resources remaining!");

		} else {
			playerPlaying.subtractResources(rent);
			squareOwner.addResources(rent);

			System.out.println(
					playerPlaying.getPlayerName() + " now has " + playerPlaying.getResources() + " resources."); // req
																													// 20
			System.out.println(squareOwner.getPlayerName() + " now has " + squareOwner.getResources() + " resources."); // req
																														// 20
		}
	}

	
	/**
	 * If the development level is below the maximum value of 4 (equivalent to a hotel in
	 * monopoly) then provides the player with an option to increase a ResearchSquare's
	 * development level by 1 in exchange for resources depending on the value of the
	 * ResearchSquare
	 * 
	 * @param player
	 * @param scanner
	 * @param board
	 */
	public void increaseDevelopment(Player player, Scanner scanner, Square board) {
		int costOfDevelopment = developmentCostCalculator(board);

		if (((ResearchSquare) board).levelOfResearchDevelopment < 4) {
			boolean flag = false;

			while (flag == false) {
				try {
					System.out.println(board.getSquareName() + " has a development level of "
							+ ((ResearchSquare) board).levelOfResearchDevelopment);
					System.out.println("Cost of development: " + costOfDevelopment);
					System.out.println(player.getPlayerName() + " has " + player.getResources());
					System.out.println("Do you want to develop this square?");
					System.out.println("1. Yes");
					System.out.println("2. No");

					int userDecision = scanner.nextInt();
					scanner.nextLine(); // clear buffer

					switch (userDecision) {
					case 1:
						player.subtractResources(costOfDevelopment);
						increaseDevelopmentLevel(board);
						setInvestmentMultiplier(board);

						if (((ResearchSquare) board).getLevelOfResearchDevelopment() == 4) {
							System.out.println(
									"Congratulations, " + board.getSquareName() + " is now at maximum development!");
						} else {
							System.out.println(board.getSquareName() + " now has a development level of "
									+ ((ResearchSquare) board).levelOfResearchDevelopment);
						}

						System.out.println(player.getPlayerName() + "now has " + player.getResources() + " resources.");
						flag = true;
						break;
					case 2:
						flag = true;
						break;
					default:
						System.out.println("Invalid user input/n");
					}
				} catch (InputMismatchException e) {
					System.err.println("Something went wrong...\n");
					scanner.nextLine(); // prepares scanner for next input to avoid infinite loop, recursive call
										// not necessary
				}
			}

		} else {
			System.out.println(((ResearchSquare) board).getSquareName() + " is already at maximum development");
		}
	}

	/**
	 * Returns a ResearchSquare's levelOfResearchDevelopment, incremented by 1
	 * @param board
	 */
	public void increaseDevelopmentLevel(Square board) {
		((ResearchSquare) board).levelOfResearchDevelopment = ((ResearchSquare) board).levelOfResearchDevelopment + 1;
	}

	/**
	 * Sets the investmentMultiplier for a ResearchSquare based on the levelOfResearchDevelopment
	 * for that square
	 * @param board
	 */
	public void setInvestmentMultiplier(Square board) {
		if (((ResearchSquare) board).levelOfResearchDevelopment == 1) {
			((ResearchSquare) board).investmentMultiplier = DEVELOPMENT_LEVEL1_INVESTMENT_MULTIPLIER;
		} else if (((ResearchSquare) board).levelOfResearchDevelopment == 2) {
			((ResearchSquare) board).investmentMultiplier = DEVELOPMENT_LEVEL2_INVESTMENT_MULTIPLIER;
		} else if (((ResearchSquare) board).levelOfResearchDevelopment == 3) {
			((ResearchSquare) board).investmentMultiplier = DEVELOPMENT_LEVEL3_INVESTMENT_MULTIPLIER;
		} else if (((ResearchSquare) board).levelOfResearchDevelopment == 4) {
			((ResearchSquare) board).investmentMultiplier = DEVELOPMENT_LEVEL4_INVESTMENT_MULTIPLIER;
		}
	}

	/**
	 * Returns a value for rent based on the price and investmentMultiplier of a ResearchSquare
	 * @param board
	 * @return
	 */
	public int rentCalculator(Square board) {
		return (int) ((double) ((ResearchSquare) board).squarePrice * ((ResearchSquare) board).investmentMultiplier);
	}

	/**
	 * Returns a value for the price of development for a ResearchSquare
	 * @param board
	 * @return
	 */
	public int developmentCostCalculator(Square board) {
		return (int) ((double) ((ResearchSquare) board).squarePrice * ResearchSquare.DEVELOPMENT_COST_MULTIPLIER);
	}

	@Override
	public void displayDetails() {
		System.out.print(this.getFieldOfResearchName() + ": " + this.getSquareName() + " | " + this.squarePrice);
		if (!squareOwner.contentEquals(" ")) {
			System.out.print(" --> Owned by: " + this.squareOwner);
		}

	}
}
