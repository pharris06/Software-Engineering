package technopoly;

import java.util.Scanner;

/**
 * Class for instantiating ThoughtShowerSquare objects to be stored within the board array
 * The role of this square essentially emulates the Free Parking square in monopoly
 * @author Andrew
 *
 */
public class ThoughtShowerSquare extends Square {

	/**
	 * default constructor
	 */
	public ThoughtShowerSquare() {

	}

	/**
	 * Constructor with args
	 * @param squareName
	 */
	public ThoughtShowerSquare(String squareName) {
		super(squareName);

	}

	@Override
	public void landingEvent(Player[] player, Square[] board, Scanner scanner, int playerTurn) {
		System.out.println("\n" + player[playerTurn].getPlayerName() + " has a thought shower while taking a helicopter view of their research projects.");
		System.out.println("Too much clear sky thinking results in " + player[playerTurn].getPlayerName() + " getting no work done this turn!");

	}

	@Override
	public void displayDetails() {
		System.out.print("*** " + this.getSquareName() + " ***");
	}

}
