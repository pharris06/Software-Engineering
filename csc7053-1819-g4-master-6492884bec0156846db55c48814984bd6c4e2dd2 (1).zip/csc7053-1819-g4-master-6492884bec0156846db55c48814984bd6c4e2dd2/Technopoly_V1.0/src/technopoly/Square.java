package technopoly;

import java.util.Scanner;

/**
 * Superclass responsible for enforcing implementation of subclass methods
 * 
 * @author david
 *
 */
public abstract class Square {

	private String squareName;
	
	/**
	 * Default constructor
	 */
	public Square() {
		
	}
	
	/**
	 * Constructor with args
	 * @param squareName
	 */
	public Square(String squareName) {
		this.setSquareName(squareName);
	}

	/**
	 * @return the squareName
	 */
	public String getSquareName() {
		return squareName;
	}

	/**
	 * @param squareName the squareName to set
	 */
	public void setSquareName(String squareName) {
		this.squareName = squareName;
	}
	
	/**
	 * Triggers the event that is associated with the specific square the player has landed on
	 */
	public abstract void landingEvent(Player[] player, Square[] board, Scanner scanner, int playerTurn);
	
	/**
	 * Displays the details of a square
	 */
	public abstract void displayDetails();
}
