package technopoly;

import java.util.Random;

/**
 * Class responsible for instantiation of Die objects and methods for their
 * utilisation
 * 
 * @author AndrewFaulkner
 *
 */
public class Die {

	public static final int DIE_SIDES = 3;

	private int dieSides;

	/**
	 * Default constructor
	 */
	public Die() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Constructor with args
	 * 
	 * @param dieSides
	 */
	public Die(int dieSides) {
		this.dieSides = dieSides;
	}

	/**
	 * @return the dieSides
	 */
	public int getDieSides() {
		return dieSides;
	}

	/**
	 * @param dieSides the dieSides to set
	 */
	public void setDieSides(int dieSides) {
		this.dieSides = dieSides;
	}

	/**
	 * Method for rolling a single die, returns back a value based on the number of
	 * sides
	 * 
	 * @return
	 */
	public int dieRoll() {
		Random rand = new Random();
		return rand.nextInt(this.dieSides) + 1;
	}
}
