package technopoly;

/**
 * Class responsible for instantiating player objects and storing methods for
 * altering player object values
 * 
 * @author matthew
 *
 */
public class Player {

	public static final int PLAYER_STARTING_RESOURCES = 3750;
	public static final int STARTING_POSITION = 0;

	private String playerName;
	private int resources;
	private int boardPosition;

	/**
	 * default constructor
	 */
	public Player() {

	}

	/**
	 * constructor with args
	 * 
	 * @param playerName
	 * @param resources
	 * @param boardPosition
	 */
	public Player(String playerName, int resources, int boardPosition) {
		this.setPlayerName(playerName);
		this.resources = resources;
		this.boardPosition = boardPosition;

	}

	/**
	 * gets playerName
	 * 
	 * @return the playerName
	 */
	public String getPlayerName() {
		return playerName;
	}

	/**
	 * sets playerName playerName, cannot be null playerName must be at least 1
	 * character
	 * 
	 * @param playerName the playerName to set
	 */
	public void setPlayerName(String playerName) throws IllegalArgumentException {
		if ((playerName == null) || (playerName.trim().length() == 0)) {
			throw new IllegalArgumentException("playerName cannot be null and must be atleast one character");
		} else {
			this.playerName = playerName;
		}
	}

	/**
	 * @return the playerFunds
	 */
	public int getResources() {
		return resources;
	}

	/**
	 * sets resources
	 * 
	 * @param resources
	 */
	public void setResources(int resources) {
		this.resources = resources;
	}

	/**
	 * @return the playerPosition
	 */
	public int getPlayerPosition() {
		return boardPosition;
	}

	/**
	 * @param playerPosition the playerPosition to set
	 */
	public void setPlayerPosition(int playerPosition) {
		this.boardPosition = playerPosition;
	}

	public void checkPassGo(Player player, int orginalPlayerPosition) {
		if (player.getPlayerPosition() < orginalPlayerPosition && player.getPlayerPosition() != 0) {
			this.addResources(ResearchGrantSquare.GRANT_AMOUNT);
			System.out.println("\nYou have completed a development cycle and been awarded a research grant"
					+ ", you get " + ResearchGrantSquare.GRANT_AMOUNT + " resources!");
			System.out.println(this.getPlayerName() + "'s new resource count is " + this.getResources());
		}
	}

	/**
	 * Adds the passed amount to the player's current resource pool
	 * 
	 * @param amount
	 * @return
	 */
	public int addResources(int amount) {
		return this.resources += amount;
	}

	/**
	 * Subtracts the passed amount from the player's current resource pool
	 * 
	 * @param amount
	 * @return
	 */
	public int subtractResources(int amount) {
		return this.resources -= amount;
	}

	/**
	 * Displays the details of the player
	 * 
	 * @param playerCount
	 */
	public void displayDetails(Square[] board) {
		System.out.print("\nName: " + this.getPlayerName());
		System.out.print("\nCurrent Position: " + board[this.getPlayerPosition()].getSquareName());
		System.out.print("\nResources: " + this.getResources());
		System.out.println();

	}

}
