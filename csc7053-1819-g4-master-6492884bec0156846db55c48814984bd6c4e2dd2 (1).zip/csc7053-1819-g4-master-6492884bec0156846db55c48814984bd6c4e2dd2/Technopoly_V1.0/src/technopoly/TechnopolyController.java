/**
 * 
 */
package technopoly;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;

/**
 * 
 * Controller for beginning Technopoly game; contains methods responsible for
 * menu operation, validation / checks of player values, beginning and ending
 * the game
 * 
 * @author David, Drew, Matt, Ricky, Paddy
 *
 */
public class TechnopolyController {

	public static Scanner scanner = new Scanner(System.in);
	public static int totalPlayers;
	public static Square[] board;
	public static Player[] players;
	public static Die[] dice;
	private static final int NUM_OF_DICE = 2;

	private static boolean gameFinished = false;

	private static ResearchSquare researchSquare = new ResearchSquare();

	/**
	 * Reference to all ResearchSquares within Square[] board
	 */
	public static ArrayList<ResearchSquare> researchSquares = new ArrayList<>();

	public static int numOfGraphicsSquares;
	public static int numOfDataSquares;
	public static int numOfFintechSquares;
	public static int numOfCyberSquares;

	/**
	 * Creates and moderates a new Technopoly game
	 * 
	 * @param args
	 * @author David
	 */
	public static void main(String[] args) {
		try {
			// Board.displayBoard(); // dummy call to demonstrate error, developer use onl

			startGame(scanner);
			// start of main
			System.out.println("\nHow many players are playing the game?  Please enter a number between 2-4: ");

			// get total players
			totalPlayers = determineTotalPlayers(scanner);
			System.out.println(totalPlayers + " players selected.");

			// create players and populate player array
			Player[] players = createPlayers(scanner, totalPlayers);

			// creation of board and populate board array
			board = Board.setUpBoard();
			dice = createDice(NUM_OF_DICE);

			researchFieldSquareCounter();

			gamePlaying(players, board, dice);

			scanner.close();

		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (InputMismatchException e) {
			System.err.println("Something went wrong...");
			scanner.nextLine(); // prepares scanner for next input to avoid infinite loop, recursive call not
								// necessary
		}

	} // end of main

	/**
	 * Prompts the user to enter the number of players and returns the integer value
	 * Validation: Accepted values are 2 - 4
	 * 
	 * @param scanner
	 * @return
	 */
	public static int determineTotalPlayers(Scanner scanner) {

		int totalPlayers = 0;
		boolean flag = false;

		while (!flag) {

			try { // try statement moved within while condition
				totalPlayers = scanner.nextInt();
				scanner.nextLine(); // clear buffer

				if (totalPlayers >= 2 && totalPlayers <= 4) {
					flag = true;
				} else if (totalPlayers < 2) {
					System.out.println("The game wouldn't be very fun with that many players!");
				} else if (totalPlayers > 4) {
					System.out.println("Too many players!");
				}

			}

			catch (InputMismatchException e) {
				System.err.println("Something went wrong...");
				scanner.nextLine(); // prepares scanner for next input to avoid infinite loop, recursive call not
									// necessary

			}

		}
		return totalPlayers;
	}

	/**
	 * Creates an array of player objects with player names determined by user input
	 * 
	 * @TODO Validation: No duplicate names Validation: User entered names must be 2
	 *       characters or longer
	 * @param scanner
	 * @param totalPlayers
	 * @return
	 * 
	 * @author = Andrew
	 */
	public static Player[] createPlayers(Scanner scanner, int totalPlayers) {
		
		// scanner.reset(); // clear buffer
		String userInput;
		int playerCount = 0;
		Player[] players = new Player[totalPlayers];

		try {

			for (int i = 0; i < totalPlayers; i++) {

				System.out.printf("\nPlayer " + (playerCount + 1) + " please enter your name: ");
				userInput = scanner.nextLine();


				while (userInput.length() < 2) {
					System.out.println("That name is too short! Please enter a name that is 2 characters or longer:");
					userInput = scanner.nextLine();
					
				}

				if (i > 0) {
					userInput = validatePlayerNames(userInput, i, players);
				}
				
				System.out.println("Hello, " + userInput + "!");
				players[i] = new Player(userInput, Player.PLAYER_STARTING_RESOURCES, Player.STARTING_POSITION);
				playerCount++;
			}
		} catch (InputMismatchException e) {
			System.err.println("Something went wrong...");
			scanner.nextLine(); // prepares scanner for next input to avoid infinite loop, recursive call not
			// necessary

		}

		return players;
	}

	/**
	 * Ensures that duplicate player names cannot be entered
	 * 
	 * @param userInput
	 * @param index
	 * @param players
	 * @return - validated player name to be entered into player array
	 * 
	 * @author David
	 */
	public static String validatePlayerNames(String userInput, int index, Player[] players) {
		String newInput = userInput;
	
		for (int loop = 0; loop < index; loop++) {
			while (players[loop].getPlayerName().equalsIgnoreCase(newInput)) {
				System.out.println("\nThat name has already been chosen, please choose another:");

				newInput = scanner.nextLine();

				while (newInput.length() < 2) {
					System.out.println("That name is too short! Please enter a name that is 2 characters or longer:");
					newInput = scanner.nextLine();
				}
				loop = 0; // Restarts loop to begin checking again
			}
		}

		return newInput;

	}

	/**
	 * Populates the researchSqaures ArrayList and adds the total number of each
	 * field type to their respective static variables
	 */
	public static void researchFieldSquareCounter() {

		for (Square square : board) {
			if (square.getClass().equals(ResearchSquare.class)) {
				researchSquares.add((ResearchSquare) square);
			}
		}

		for (int loop = 0; loop < researchSquares.size(); loop++) {

			// Checks that the class of the square is a ResearchSquare if

			switch (researchSquares.get(loop).getFieldOfResearchName()) {
			case ResearchSquare.FIELD_GRAPHICS:
				numOfGraphicsSquares++;
				break;
			case ResearchSquare.FIELD_DATA:
				numOfDataSquares++;
				break;
			case ResearchSquare.FIELD_FINTECH:
				numOfFintechSquares++;
				break;
			case ResearchSquare.FIELD_CYBER:
				numOfCyberSquares++;
				break;
			}

		}

	}

	/**
	 * Starts a new Technopoly game
	 * 
	 * @param scanner
	 */
	public static void startGame(Scanner scanner) {

		int userInput = 0;

		do {

			System.out.println("Welcome to TECHNOPOLY:");
			System.out.println("1. New Game");
			System.out.println("2. Quit");

			try {
				userInput = scanner.nextInt();
				if (userInput == 1) {

				} else if (userInput == 2) {
					System.out.println("Goodbye!");
					System.exit(0);
				} else {
					System.out.println("Please enter a valid number 1-2.");
				}

			} catch (InputMismatchException e) {
				System.err.println("Something went wrong...\n");
				scanner.nextLine(); // prepares scanner for next input to avoid infinite loop, recursive call not
									// necessary
			}
		} while (userInput != 1 && userInput != 2);

	}

	/**
	 * 
	 * Creates new dice objects based on the method argument, creating and
	 * populating an array of Die
	 * 
	 * @param numOfDice
	 * @return
	 */
	public static Die[] createDice(int numOfDice) {

		Die[] dice = new Die[numOfDice];

		for (int loop = 0; loop < numOfDice; loop++) {
			dice[loop] = new Die(Die.DIE_SIDES);
		}

		return dice;
	}

	/**
	 * 
	 * Method which loops through the turns of each player, calling methods for each
	 * respective aspect of a player's turn. Continues until gameFinished resolves
	 * as true. Checks if a player is out of resources before ending turn.
	 * 
	 * @param players
	 * @param board
	 * @param dice
	 * @throws InterruptedException
	 */
	public static void gamePlaying(Player[] players, Square[] board, Die[] dice) throws InterruptedException {

		while (!gameFinished) {
			for (int playerTurn = 0; playerTurn < players.length; playerTurn++) {
				System.out.println("\n****************************************");
				System.out.println("\tBEGINNING " + players[playerTurn].getPlayerName().toUpperCase() + "'S TURN");
				System.out.println("****************************************\n");

				System.out.printf(
						"Current Location: " + board[players[playerTurn].getPlayerPosition()].getSquareName() + "\n");

				// Prompt to move, show assets, buy property

				boolean flag = false;
				while (!flag) {
					try {

						System.out.println("\nWhat would you like to do?\n");
						System.out.println("1. Roll Dice");
						System.out.println("2. Invest in Area of Research");
						System.out.println("3. View Assets");
						System.out.println("4. Display Board");
						System.out.println("5. Quit Game\n");

						int userSelection = scanner.nextInt();
						scanner.nextLine(); // Clearing buffer
						switch (userSelection) {
						case 1:
							Board.movePlayer(players[playerTurn], dice);
							flag = true;
							break;
						case 2:
							increaseDevelopmentSelection(players[playerTurn], scanner, board);
							break;
						case 3:
							players[playerTurn].displayDetails(board);
							break;
						case 4:
							Board.displayBoard(players);
							break;
						case 5:
							gameFinished = true;
							gameOver(players);
							break;
						default:
							System.out.println("Please input a valid option:");
						}

					} catch (InputMismatchException e) {
						System.err.println("Something went wrong...\n");
						scanner.nextLine(); // prepares scanner for next input to avoid infinite loop, recursive call
											// not
						// necessary
					}
				}

				board[players[playerTurn].getPlayerPosition()].landingEvent(players, board, scanner, playerTurn);

				if (players[playerTurn].getResources() <= 0) {
					System.out.println(players[playerTurn].getPlayerName() + " has run out of resources and cannot continue!");
					gameFinished = true;
					gameOver(players);
				}

				// End turn prompt (end / show assets)

				boolean turnOver = false;
				while (!turnOver) {
					try {

						System.out.println("\nWhat would you like to do?\n");
						System.out.println("1. End Turn");
						System.out.println("2. View Assets");
						System.out.println("3. Display Board");
						System.out.println("4. Quit Game\n");

						int userSelection = scanner.nextInt();
						scanner.nextLine(); // Clearing buffer
						switch (userSelection) {
						case 1:
							turnOver = true;
							break;
						case 2:
							players[playerTurn].displayDetails(board);
							break;
						case 3:
							Board.displayBoard(players);
							break;
						case 4:
							gameFinished = true;
							gameOver(players);
							break;
						default:
							System.out.println("Please input a valid option:");
						}
					} catch (InputMismatchException e) {
						System.err.println("Something went wrong...\n");
						scanner.nextLine(); // prepares scanner for next input to avoid infinite loop, recursive call
											// not
						// necessary
					}
				}
			}

		}
	}

	/**
	 * 
	 * Selection menu for choosing a field in which the player wants to develop,
	 * calls the fieldOwnerShipCheck and increaseDevelopment methods if a user has
	 * all areas within a given field
	 * 
	 * @param player
	 * @param scanner
	 * @param board
	 * @author david
	 */
	public static void increaseDevelopmentSelection(Player player, Scanner scanner, Square[] board) {

		boolean flag = false;

		while (!flag) {

			System.out.println("\nWhich Field Would You Like To Develop?\n");
			System.out.println("1. " + ResearchSquare.FIELD_GRAPHICS);
			System.out.println("2. " + ResearchSquare.FIELD_DATA);
			System.out.println("3. " + ResearchSquare.FIELD_FINTECH);
			System.out.println("4. " + ResearchSquare.FIELD_CYBER);
			System.out.println("5. Return To Previous Menu\n");

			int userInput = scanner.nextInt();
			scanner.nextLine(); // clear buffer

			switch (userInput) {
			case 1:

				if (fieldOwnershipCheck(player, ResearchSquare.FIELD_GRAPHICS)) {

					System.out.println("Which area would you like to develop?");
					System.out.println("1. Physically Based Rendering");
					System.out.println("2. Virtual Reality");

					int userGraphicsDecision = scanner.nextInt();
					scanner.nextLine(); // clear buffer

					switch (userGraphicsDecision) {
					case 1:
						researchSquare.increaseDevelopment(player, scanner, board[1]);
						break;
					case 2:
						researchSquare.increaseDevelopment(player, scanner, board[2]);
						break;
					default:
						System.out.println("Please input a valid option:");
					}

				} else {
					System.out.println(
							"You do not own all the areas within the " + ResearchSquare.FIELD_GRAPHICS + " field.");
				}
				break;

			case 2:

				if (fieldOwnershipCheck(player, ResearchSquare.FIELD_DATA)) {

					System.out.println("Which area would you like to develop?");
					System.out.println("1. Business Intelligence");
					System.out.println("2. Analytics");
					System.out.println("3. Machine Learning");

					int userGraphicsDecision = scanner.nextInt();
					scanner.nextLine(); // clear buffer

					switch (userGraphicsDecision) {
					case 1:
						researchSquare.increaseDevelopment(player, scanner, board[3]);
						break;
					case 2:
						researchSquare.increaseDevelopment(player, scanner, board[4]);
						break;
					case 3:
						researchSquare.increaseDevelopment(player, scanner, board[5]);
						break;
					default:
						System.out.println("Please input a valid option:");
					}

				} else {
					System.out.println(
							"You do not own all the areas within the " + ResearchSquare.FIELD_DATA + " field.");
				}

				break;
			case 3:

				if (fieldOwnershipCheck(player, ResearchSquare.FIELD_FINTECH)) {

					System.out.println("Which area would you like to develop?");
					System.out.println("1. Payment Processing");
					System.out.println("2. Market Analysis");

					int userGraphicsDecision = scanner.nextInt();
					scanner.nextLine(); // clear buffer

					switch (userGraphicsDecision) {
					case 1:
						researchSquare.increaseDevelopment(player, scanner, board[7]);
						break;
					case 2:
						researchSquare.increaseDevelopment(player, scanner, board[8]);
						break;
					default:
						System.out.println("Please input a valid option:");
					}

				} else {
					System.out.println(
							"You do not own all the areas within the " + ResearchSquare.FIELD_FINTECH + " field.");
				}
				break;
			case 4:

				if (fieldOwnershipCheck(player, ResearchSquare.FIELD_CYBER)) {

					System.out.println("Which area would you like to develop?");
					System.out.println("1. Viruses");
					System.out.println("2. Phishing");
					System.out.println("3. Spyware");

					int userGraphicsDecision = scanner.nextInt();
					scanner.nextLine(); // clear buffer

					switch (userGraphicsDecision) {
					case 1:
						researchSquare.increaseDevelopment(player, scanner, board[9]);
						break;
					case 2:
						researchSquare.increaseDevelopment(player, scanner, board[10]);
						break;
					case 3:
						researchSquare.increaseDevelopment(player, scanner, board[11]);
						break;
					default:
						System.out.println("Please input a valid option:");
					}

				} else {
					System.out.println(
							"You do not own all the areas within the " + ResearchSquare.FIELD_CYBER + " field.");
				}
				break;
			case 5:
				flag = true;
			default:
				System.out.println("Please input a valid option:");
			}

		}

	}

	/**
	 * Checks that a given player is the owner of all areas within a selected field,
	 * returning true or false
	 * 
	 * @param player
	 * @param selectedField
	 * @return - true if a player owns all areas within a selected field - false if
	 *         a player does not own all areas within a selected field
	 * 
	 * @author david
	 */
	public static boolean fieldOwnershipCheck(Player player, String selectedField) {

		int numSquaresOwned = 0;
		for (int loop = 0; loop < researchSquares.size(); loop++) {

			if (researchSquares.get(loop).getFieldOfResearchName().equals(selectedField)
					&& researchSquares.get(loop).getSquareOwner().equals(player.getPlayerName())) {
				numSquaresOwned++;
			}

		}

		switch (selectedField) {
		case ResearchSquare.FIELD_GRAPHICS:
			if (numSquaresOwned == numOfGraphicsSquares) {
				return true;
			}
			break;
		case ResearchSquare.FIELD_DATA:
			if (numSquaresOwned == numOfDataSquares) {
				return true;
			}
			break;
		case ResearchSquare.FIELD_FINTECH:
			if (numSquaresOwned == numOfFintechSquares) {
				return true;
			}
			break;
		case ResearchSquare.FIELD_CYBER:
			if (numSquaresOwned == numOfCyberSquares) {
				return true;
			}
			break;
		default:
			return false;
		}

		return false;

	}

	/**
	 * 
	 * Prints players in order of most resources with their ranking, closes scanner
	 * and system
	 * 
	 * @param players
	 */
	public static void gameOver(Player[] players) {

		Set<Integer> playerResourcesNoDuplicates = new LinkedHashSet<Integer>();
		ArrayList<String> playerNameHolder = new ArrayList<>();
		int playerRanking = 0;
		String[] ranks = { " ", "st", "nd", "rd", "th" };
		int[] playerResourcesSorted;
		int descendingIndex = 0;

		for (int loop = 0; loop < players.length; loop++) {
			playerResourcesNoDuplicates.add(players[loop].getResources());
		}

		playerResourcesSorted = new int[playerResourcesNoDuplicates.size()];
		int[] playerResources = new int[playerResourcesNoDuplicates.size()];

		int index = 0;
		for (Integer i : playerResourcesNoDuplicates) {
			playerResources[index++] = i;
		}

		Arrays.sort(playerResources);
		
		for(int i = playerResources.length -1; i >= 0; i--) {
			playerResourcesSorted[i] = playerResources[descendingIndex];
			descendingIndex++;
		}

		System.out.println("\n****************************************");
		System.out.println("\tGAME OVER - RESULTS");
		System.out.println("****************************************");
		
		for (int resourcesLoop = 0; resourcesLoop < playerResourcesSorted.length; resourcesLoop++) {
			for (int playersLoop = 0; playersLoop < players.length; playersLoop++) {
				if (players[playersLoop].getResources() == playerResourcesSorted[resourcesLoop]) {
					playerNameHolder.add(players[playersLoop].getPlayerName());			
				}
			}

			System.out.println();
			if (playerNameHolder.size() == 1) {
				System.out.print(++playerRanking + ranks[playerRanking] + " --> " /*+ playerNameHolder + " Final Resources: " + players[y].getResources()*/);
				
				
				for (String playerName : playerNameHolder) {
					for (Player player : players) {
						if (player.getPlayerName().equals(playerName)) {
							System.out.print(player.getPlayerName() + " (Final Resources: " + player.getResources() + ")");
						}
					}
				}
			} else {
				System.out.print("Joint " + ++playerRanking + ranks[playerRanking] + " --> ");
				for (String playerName : playerNameHolder) {
					for (Player player : players) {
						if (player.getPlayerName().equals(playerName)) {
							System.out.print(player.getPlayerName() + " (Final Resources: " + player.getResources() + ") | ");
						}
					}
				}
			}
			System.out.println();

			playerNameHolder.clear();
		}
		scanner.close();
		System.exit(0);
	}
	

}
