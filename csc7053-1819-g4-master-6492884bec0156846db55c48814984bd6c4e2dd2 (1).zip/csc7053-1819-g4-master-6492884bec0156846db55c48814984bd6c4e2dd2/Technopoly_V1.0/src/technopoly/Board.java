package technopoly;

/**
 * Class for instantiating the Square[] board and controlling movement of
 * players around the board
 * 
 * @author david
 *
 */
public class Board {

	// number of special event squares, e.g. Research Grant / Thought Shower
	private static final int NUM_OF_SPECIAL_SQ = 2;
	private static final int NUM_OF_RESEARCH_SQ = ResearchSquare.researchSquareNames.length;

	public static final int BOARD_SIZE = NUM_OF_RESEARCH_SQ + NUM_OF_SPECIAL_SQ;
	public static Square[] board = new Square[BOARD_SIZE];

	/**
	 * Creates a new board and assigns squares to their designated position within
	 * the board array
	 */
	public static Square[] setUpBoard() {

		int count = 0;

		for (int arrayIndex = 0; arrayIndex < board.length; arrayIndex++) {

			if (arrayIndex == 0) {
				board[arrayIndex] = new ResearchGrantSquare("Research Grant");

			} else if (arrayIndex == 6) {
				board[arrayIndex] = new ThoughtShowerSquare("Thought Shower");

			} else if (arrayIndex > 0 && arrayIndex < 3) {
				board[arrayIndex] = new ResearchSquare(ResearchSquare.researchSquareNames[count],
						ResearchSquare.FIELD_GRAPHICS, ResearchSquare.DEFAULT_DEVELOPMENT_LEVEL,
						ResearchSquare.GRAPHICS_BASE_PRICE, ResearchSquare.DEFAULT_INVESTMENT_MULTIPLIER);
				count++;

			} else if (arrayIndex > 2 && arrayIndex < 6) {
				board[arrayIndex] = new ResearchSquare(ResearchSquare.researchSquareNames[count],
						ResearchSquare.FIELD_DATA, ResearchSquare.DEFAULT_DEVELOPMENT_LEVEL,
						ResearchSquare.DATA_BASE_PRICE, ResearchSquare.DEFAULT_INVESTMENT_MULTIPLIER);
				count++;

			} else if (arrayIndex > 6 && arrayIndex < 9) {
				board[arrayIndex] = new ResearchSquare(ResearchSquare.researchSquareNames[count],
						ResearchSquare.FIELD_FINTECH, ResearchSquare.DEFAULT_DEVELOPMENT_LEVEL,
						ResearchSquare.FINTECH_BASE_PRICE, ResearchSquare.DEFAULT_INVESTMENT_MULTIPLIER);
				count++;
			} else {
				board[arrayIndex] = new ResearchSquare(ResearchSquare.researchSquareNames[count],
						ResearchSquare.FIELD_CYBER, ResearchSquare.DEFAULT_DEVELOPMENT_LEVEL,
						ResearchSquare.CYBER_BASE_PRICE, ResearchSquare.DEFAULT_INVESTMENT_MULTIPLIER);
				count++;
			}
		}

		return board;

	}

	/**
	 * Method to display the current game's board
	 */
	public static void displayBoard(Player[] players) {
		try {
			int count = 0;
			System.out.println();
			for (int loop = 0; loop < board.length; loop++) {
				System.out.print("Square " + ++count + ": ");
				board[loop].displayDetails();
				System.out.print("\t\t\t- Player(s) here:");
				for (Player player : players) {

					if (player.getPlayerPosition() == loop) {

						System.out.print(" - " + player.getPlayerName());
					}
				}
				System.out.printf("\n");

			}
		} catch (Exception e) { // if a board does not exist, allow program to continue
			System.err.println("Tried to display a game board but one does not exist");
			e.printStackTrace();

		}
	}

	/**
	 * Sets the player's position relative to the board, calling the checkPassGo
	 * method to check if the player has completed a loop of the board
	 * 
	 * @param player
	 * @param dice
	 * @throws InterruptedException
	 */
	public static void movePlayer(Player player, Die[] dice) throws InterruptedException {

		int totalRoll = 0;
		int dieCount = 1;
		int originalPosition = player.getPlayerPosition();

		
		System.out.print("\nRolling ");
		for (int i = 0; i < 8; i++) {
			Thread.sleep(250);
			System.out.print(" . ");
		}
		
		System.out.println();

		for (int loop = 0; loop < dice.length; loop++) {
			int dieRoll = dice[loop].dieRoll();
			System.out.println("Die " + dieCount++ + " rolled: " + dieRoll);

			Thread.sleep(250);

			totalRoll += dieRoll;

			Thread.sleep(250);

		}

		System.out.println("\nTotal roll: " + totalRoll);

		int areaToMoveTo = (player.getPlayerPosition() + totalRoll);

		if (areaToMoveTo >= board.length) {
			player.setPlayerPosition(areaToMoveTo - board.length);
		} else {
			player.setPlayerPosition(areaToMoveTo);
		}

		player.checkPassGo(player, originalPosition);

		System.out.println("\nNew location of " + player.getPlayerName() + ": "
				+ board[player.getPlayerPosition()].getSquareName());
		System.out.println();

	}
}
