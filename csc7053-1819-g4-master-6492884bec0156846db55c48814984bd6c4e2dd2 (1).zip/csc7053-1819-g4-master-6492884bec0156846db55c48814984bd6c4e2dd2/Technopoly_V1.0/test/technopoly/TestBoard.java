package technopoly;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestBoard {

	Die testDie1, testDie2;
	private static Die[] dieArray;
	private static Player testPlayer;
	private static String validPlayerName;
	private static int playerAtStartOfBoard, playerAtEndOfBoard;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		TechnopolyController.board = Board.setUpBoard();
		TechnopolyController.researchFieldSquareCounter();
		
		dieArray = new Die[2];
		
		testPlayer = new Player();
		
		Die oneSidedTestDie1 = new Die(1);
		Die oneSidedTestDie2 = new Die(1);
		dieArray[0] = oneSidedTestDie1;
		dieArray[1] = oneSidedTestDie2;
		
		validPlayerName = "Valid Name";
		playerAtStartOfBoard = 0;
		playerAtEndOfBoard = 11;
		
	}

	@Before
	public void setUp() throws Exception {

		
		
		
	}

	@Test
	public void testMovePlayer_PlayerPosition_ExpectedPlayerPosition2() {
		int playerExpectedPostion = 2;
		testPlayer.setPlayerName(validPlayerName);
		testPlayer.setPlayerPosition(playerAtStartOfBoard);
		
		try {
			Board.movePlayer(testPlayer, dieArray);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		assertEquals(playerExpectedPostion, testPlayer.getPlayerPosition());
	}
	
	@Test
	public void testMovePlayer_PlayerPositionCorrectlyLoopsRoundBoard_ExpectedPlayerPosition1() {
		int playerExpectedPostion = 1;
		testPlayer.setPlayerName(validPlayerName);
		testPlayer.setPlayerPosition(playerAtEndOfBoard);
		
		try {
			Board.movePlayer(testPlayer, dieArray);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		assertEquals(playerExpectedPostion, testPlayer.getPlayerPosition());
	}

}
