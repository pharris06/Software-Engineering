package technopoly;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestTechnopolyController {
	
	private static Player testPlayer;
	private static String validPlayerName;
	private static String validPlayerName2;
	private static ResearchSquare testResearchSquare1;
	private static ResearchSquare testResearchSquare2;
	private static ResearchSquare testResearchSquare3;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		TechnopolyController.board = Board.setUpBoard();
		TechnopolyController.researchFieldSquareCounter();
		
		testPlayer = new Player();
		validPlayerName = "Valid Name";
		validPlayerName2 = "Different Valid Name";
		testPlayer.setPlayerName(validPlayerName);
		
		testResearchSquare1 = new ResearchSquare();
		testResearchSquare2 = new ResearchSquare();
		testResearchSquare3 = new ResearchSquare();
		
	}

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testValidFieldOwnership_PlayerNameSetAsSquareOwnerForAllTestFields_ExpectedTrue() {
		testResearchSquare1.setSquareOwner(validPlayerName);
		testResearchSquare1.setFieldOfResearchName(ResearchSquare.FIELD_DATA);
		
		testResearchSquare2.setSquareOwner(validPlayerName);
		testResearchSquare2.setFieldOfResearchName(ResearchSquare.FIELD_DATA);
		
		testResearchSquare3.setSquareOwner(validPlayerName);
		testResearchSquare3.setFieldOfResearchName(ResearchSquare.FIELD_DATA);
		
		TechnopolyController.researchSquares.set(2, testResearchSquare1);
		TechnopolyController.researchSquares.set(3, testResearchSquare2);
		TechnopolyController.researchSquares.set(4, testResearchSquare3);
		
		assertTrue(TechnopolyController.fieldOwnershipCheck(testPlayer, ResearchSquare.FIELD_DATA));
	}
	
	@Test
	public void testFieldOwnership_PlayerNameSetAsSquareOwnerForTwoOfThreeTestFields_ExpectedFalse() {
		
		testResearchSquare1.setSquareOwner(validPlayerName);
		testResearchSquare1.setFieldOfResearchName(ResearchSquare.FIELD_DATA);
		
		testResearchSquare2.setSquareOwner(validPlayerName);
		testResearchSquare2.setFieldOfResearchName(ResearchSquare.FIELD_DATA);
		
		testResearchSquare3.setSquareOwner(validPlayerName2);
		testResearchSquare3.setFieldOfResearchName(ResearchSquare.FIELD_DATA);
		
		TechnopolyController.researchSquares.set(2, testResearchSquare1);
		TechnopolyController.researchSquares.set(3, testResearchSquare2);
		TechnopolyController.researchSquares.set(4, testResearchSquare3);
		
		assertFalse(TechnopolyController.fieldOwnershipCheck(testPlayer, ResearchSquare.FIELD_DATA));
	}

}
