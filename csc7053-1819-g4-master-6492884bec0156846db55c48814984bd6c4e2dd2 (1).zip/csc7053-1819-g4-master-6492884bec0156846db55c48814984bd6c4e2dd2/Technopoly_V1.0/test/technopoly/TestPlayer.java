package technopoly;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class TestPlayer {
	
	int resources, testOriginalPlayerPosition, testPlayerNewPosition;
	Player validPlayer;
	

	@Before
	public void setUp() throws Exception {
		resources = 1;
		validPlayer = new Player("Test", resources, 0);
	}

	@Test
	public void testCheckPassGo_PlayerNewPositionLessThanOriginal_ExpectGRANT_AMOUNTAdditionToResources() {
		// arrange
		testOriginalPlayerPosition = 8;
		testPlayerNewPosition = 3;
		validPlayer = new Player("Test", 3750, testPlayerNewPosition);
		int expected = 4250;
		
		// act
		validPlayer.checkPassGo(validPlayer, testOriginalPlayerPosition);
		int actual = validPlayer.getResources();
		
		// assert
		assertEquals(expected, actual);
	}
	
	@Test
	public void testCheckPassGo_PlayerNewPositionGreaterThanOriginal_ExpectNoChange() {
		testOriginalPlayerPosition = 1;
		testPlayerNewPosition = 5;
		validPlayer = new Player("Test", 3750, testPlayerNewPosition);
		int expected = 3750;
		
		// act
		validPlayer.checkPassGo(validPlayer, testOriginalPlayerPosition);
		int actual = validPlayer.getResources();
		
		// assert
		assertEquals(expected, actual);
	}

	@Test
	public void testAddResources_amountToBeAdded_Expected11Resources() {
		validPlayer.addResources(10);
		int actual = validPlayer.getResources();
		int expected = 11;
		
		assertEquals(expected, actual);
		
		
	}

	@Test
	public void testSubtractResources() {
		validPlayer.subtractResources(1);
		int actual = validPlayer.getResources();
		int expected = 0;
		
		assertEquals(expected, actual);
	}

}
